require("dotenv").config();
const express = require("express");
const path = require("path");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const rateLimit = require("express-rate-limit");
const { pool, initDb } = require("./db");
const { COOKIE_NAME, signToken, authRequired, adminRequired } = require("./auth");

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error("LỖI: Hãy đặt JWT_SECRET dài ít nhất 32 ký tự trong file .env");
  process.exit(1);
}
const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "64kb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "../public"), { extensions: ["html"] }));
app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false }));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, message: { error: "Quá nhiều lần thử. Hãy thử lại sau 15 phút." } });
const clean = (s, max=300) => String(s ?? "").trim().slice(0, max);
const validUrl = (value) => {
  try { const u = new URL(value); return ["http:", "https:"].includes(u.protocol); } catch { return false; }
};
const slugify = (s) => clean(s, 40).toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9-]/g,"-").replace(/-+/g,"-").replace(/^-|-$/g,"");
async function ownedBio(req, res, bioId) {
  const q = await pool.query("SELECT * FROM bios WHERE id=$1 AND user_id=$2", [bioId, req.user.id]);
  if (!q.rowCount) { res.status(404).json({ error: "Không tìm thấy trang Bio." }); return null; }
  return q.rows[0];
}
app.get("/api/health", async (_req,res) => {
  try { await pool.query("SELECT 1"); res.json({ status:"ok", service:"HMKEY Bio Link Pro" }); }
  catch { res.status(503).json({ status:"error", error:"Không kết nối được cơ sở dữ liệu." }); }
});
app.post("/api/auth/register", authLimiter, async (req,res) => {
  const email = clean(req.body.email, 254).toLowerCase();
  const password = String(req.body.password || "");
  const displayName = clean(req.body.displayName, 60) || "HMKEY User";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:"Email không hợp lệ."});
  if (password.length < 10) return res.status(400).json({error:"Mật khẩu phải có ít nhất 10 ký tự."});
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query("INSERT INTO users(email,password_hash,display_name) VALUES($1,$2,$3) RETURNING id,email,display_name,role", [email,hash,displayName]);
    const user = result.rows[0];
    const slug = slugify(displayName) || `hmkey-${user.id}`;
    const bio = await pool.query("INSERT INTO bios(user_id,slug,display_name,bio) VALUES($1,$2,$3,$4) RETURNING id,slug,display_name,bio,avatar_url,cover_url,theme,accent_color,music_url,music_title,is_published", [user.id, `${slug}-${user.id}`, displayName, "Chào mừng đến với Bio của mình!"]);
    res.cookie(COOKIE_NAME, signToken(user), { httpOnly:true, sameSite:"lax", secure:process.env.COOKIE_SECURE==="true", maxAge:7*24*60*60*1000 });
    res.status(201).json({ user, bios:[bio.rows[0]] });
  } catch(e) {
    if (e.code === "23505") return res.status(409).json({error:"Email đã được sử dụng."});
    console.error(e); res.status(500).json({error:"Không thể tạo tài khoản."});
  }
});
app.post("/api/auth/login", authLimiter, async (req,res) => {
  const email = clean(req.body.email,254).toLowerCase(), password = String(req.body.password || "");
  const q = await pool.query("SELECT * FROM users WHERE email=$1", [email]);
  if (!q.rowCount || !(await bcrypt.compare(password,q.rows[0].password_hash))) return res.status(401).json({error:"Email hoặc mật khẩu không đúng."});
  const user = q.rows[0];
  if (process.env.ADMIN_EMAIL && email === process.env.ADMIN_EMAIL.toLowerCase() && user.role !== "admin") {
    await pool.query("UPDATE users SET role='admin' WHERE id=$1",[user.id]); user.role = "admin";
  }
  res.cookie(COOKIE_NAME, signToken(user), { httpOnly:true, sameSite:"lax", secure:process.env.COOKIE_SECURE==="true", maxAge:7*24*60*60*1000 });
  res.json({user:{id:user.id,email:user.email,display_name:user.display_name,role:user.role}});
});
app.post("/api/auth/logout", (_req,res) => { res.clearCookie(COOKIE_NAME,{httpOnly:true,sameSite:"lax",secure:process.env.COOKIE_SECURE==="true"}); res.json({ok:true}); });
app.get("/api/me", authRequired, async (req,res) => {
  const u = await pool.query("SELECT id,email,display_name,role,created_at FROM users WHERE id=$1",[req.user.id]);
  const bios = await pool.query("SELECT * FROM bios WHERE user_id=$1 ORDER BY created_at DESC",[req.user.id]);
  res.json({user:u.rows[0],bios:bios.rows});
});
app.post("/api/bios", authRequired, async (req,res) => {
  const displayName = clean(req.body.display_name,60) || "HMKEY";
  let slug = slugify(req.body.slug || displayName);
  if (slug.length < 3) return res.status(400).json({error:"Đường dẫn phải có ít nhất 3 ký tự."});
  try {
    const q = await pool.query("INSERT INTO bios(user_id,slug,display_name,bio) VALUES($1,$2,$3,$4) RETURNING *",[req.user.id,slug,displayName,clean(req.body.bio,300)]);
    res.status(201).json(q.rows[0]);
  } catch(e) { if(e.code==="23505") return res.status(409).json({error:"Đường dẫn này đã được sử dụng."}); throw e; }
});
app.patch("/api/bios/:id", authRequired, async (req,res) => {
  const bio = await ownedBio(req,res,req.params.id); if(!bio) return;
  const b = req.body;
  const slug = b.slug === undefined ? bio.slug : slugify(b.slug);
  if (slug.length < 3) return res.status(400).json({error:"Đường dẫn phải có ít nhất 3 ký tự."});
  for (const key of ["avatar_url","cover_url","music_url"]) if (b[key] && !validUrl(b[key])) return res.status(400).json({error:`Địa chỉ ${key} phải là URL http/https hợp lệ.`});
  try {
    const q = await pool.query(`UPDATE bios SET slug=$1,display_name=$2,bio=$3,avatar_url=$4,cover_url=$5,theme=$6,accent_color=$7,music_url=$8,music_title=$9,is_published=$10,updated_at=NOW() WHERE id=$11 RETURNING *`,
      [slug,clean(b.display_name ?? bio.display_name,60),clean(b.bio ?? bio.bio,300),clean(b.avatar_url ?? bio.avatar_url,1000),clean(b.cover_url ?? bio.cover_url,1000),clean(b.theme ?? bio.theme,30),/^#[0-9a-fA-F]{6}$/.test(b.accent_color||"")?b.accent_color:bio.accent_color,clean(b.music_url ?? bio.music_url,1000),clean(b.music_title ?? bio.music_title,100),b.is_published===undefined?bio.is_published:!!b.is_published,bio.id]);
    res.json(q.rows[0]);
  } catch(e) { if(e.code==="23505") return res.status(409).json({error:"Đường dẫn đã được sử dụng."}); throw e; }
});
app.delete("/api/bios/:id", authRequired, async (req,res) => {
  const bio=await ownedBio(req,res,req.params.id); if(!bio) return;
  const count=await pool.query("SELECT COUNT(*)::int AS n FROM bios WHERE user_id=$1",[req.user.id]);
  if(count.rows[0].n<=1) return res.status(400).json({error:"Bạn cần giữ lại ít nhất một trang Bio."});
  await pool.query("DELETE FROM bios WHERE id=$1",[bio.id]); res.json({ok:true});
});
app.get("/api/bios/:slug/public", async (req,res) => {
  const q=await pool.query("SELECT id,slug,display_name,bio,avatar_url,cover_url,theme,accent_color,music_url,music_title FROM bios WHERE slug=$1 AND is_published=TRUE",[clean(req.params.slug,80)]);
  if(!q.rowCount) return res.status(404).json({error:"Không tìm thấy Bio."});
  const bio=q.rows[0];
  const links=await pool.query("SELECT id,title,url,icon,sort_order FROM links WHERE bio_id=$1 AND is_active=TRUE ORDER BY sort_order,id",[bio.id]);
  const socials=await pool.query("SELECT platform,url FROM social_links WHERE bio_id=$1 ORDER BY sort_order,id",[bio.id]);
  const visitor = (req.ip || "").split(".").slice(0,3).join(".") + "|" + (req.get("user-agent")||"").slice(0,80);
  const crypto=require("crypto");
  const visitorHash=crypto.createHash("sha256").update(visitor).digest("hex");
  await pool.query("INSERT INTO analytics_events(bio_id,event_type,visitor_hash) VALUES($1,'view',$2)",[bio.id,visitorHash]);
  res.json({...bio,links:links.rows,socials:socials.rows});
});
app.post("/api/public/click", async (req,res) => {
  const bioId=Number(req.body.bio_id), linkId=Number(req.body.link_id);
  if(!Number.isInteger(bioId)||!Number.isInteger(linkId)) return res.status(400).json({error:"Dữ liệu không hợp lệ."});
  const q=await pool.query("SELECT l.id FROM links l JOIN bios b ON b.id=l.bio_id WHERE l.id=$1 AND l.bio_id=$2 AND l.is_active=TRUE AND b.is_published=TRUE",[linkId,bioId]);
  if(!q.rowCount) return res.status(404).json({error:"Liên kết không tồn tại."});
  await pool.query("INSERT INTO analytics_events(bio_id,event_type,link_id) VALUES($1,'click',$2)",[bioId,linkId]); res.json({ok:true});
});
app.post("/api/public/contact", async (req,res) => {
  const bioId=Number(req.body.bio_id), name=clean(req.body.name,80), email=clean(req.body.email,254), message=clean(req.body.message,2000);
  if(!Number.isInteger(bioId)||name.length<2||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||message.length<5) return res.status(400).json({error:"Vui lòng kiểm tra lại thông tin."});
  const b=await pool.query("SELECT id FROM bios WHERE id=$1 AND is_published=TRUE",[bioId]); if(!b.rowCount) return res.status(404).json({error:"Không tìm thấy Bio."});
  await pool.query("INSERT INTO contact_messages(bio_id,sender_name,sender_email,message) VALUES($1,$2,$3,$4)",[bioId,name,email,message]);
  res.status(201).json({ok:true,message:"Đã gửi tin nhắn thành công."});
});
app.get("/api/bios/:id/links", authRequired, async (req,res) => {
  const bio=await ownedBio(req,res,req.params.id); if(!bio) return;
  const q=await pool.query("SELECT * FROM links WHERE bio_id=$1 ORDER BY sort_order,id",[bio.id]); res.json(q.rows);
});
app.post("/api/bios/:id/links", authRequired, async (req,res) => {
  const bio=await ownedBio(req,res,req.params.id); if(!bio) return;
  const title=clean(req.body.title,80), url=clean(req.body.url,1000);
  if(title.length<1||!validUrl(url)) return res.status(400).json({error:"Tên hoặc URL liên kết không hợp lệ."});
  const q=await pool.query("INSERT INTO links(bio_id,title,url,icon,sort_order) VALUES($1,$2,$3,$4,$5) RETURNING *",[bio.id,title,url,clean(req.body.icon,8)||"🔗",Number(req.body.sort_order)||0]);
  res.status(201).json(q.rows[0]);
});
app.patch("/api/links/:id", authRequired, async (req,res) => {
  const q=await pool.query("SELECT l.* FROM links l JOIN bios b ON b.id=l.bio_id WHERE l.id=$1 AND b.user_id=$2",[req.params.id,req.user.id]);
  if(!q.rowCount) return res.status(404).json({error:"Không tìm thấy liên kết."});
  const l=q.rows[0], title=clean(req.body.title??l.title,80), url=clean(req.body.url??l.url,1000);
  if(!validUrl(url)||!title) return res.status(400).json({error:"Tên hoặc URL không hợp lệ."});
  const out=await pool.query("UPDATE links SET title=$1,url=$2,icon=$3,sort_order=$4,is_active=$5 WHERE id=$6 RETURNING *",[title,url,clean(req.body.icon??l.icon,8),Number(req.body.sort_order??l.sort_order)||0,req.body.is_active===undefined?l.is_active:!!req.body.is_active,l.id]);
  res.json(out.rows[0]);
});
app.delete("/api/links/:id", authRequired, async (req,res) => {
  const q=await pool.query("DELETE FROM links l USING bios b WHERE l.bio_id=b.id AND l.id=$1 AND b.user_id=$2 RETURNING l.id",[req.params.id,req.user.id]);
  if(!q.rowCount) return res.status(404).json({error:"Không tìm thấy liên kết."}); res.json({ok:true});
});
app.get("/api/bios/:id/analytics", authRequired, async (req,res) => {
  const bio=await ownedBio(req,res,req.params.id); if(!bio) return;
  const totals=await pool.query("SELECT COUNT(*) FILTER(WHERE event_type='view')::int AS views, COUNT(*) FILTER(WHERE event_type='click')::int AS clicks FROM analytics_events WHERE bio_id=$1",[bio.id]);
  const days=await pool.query("SELECT TO_CHAR(created_at AT TIME ZONE 'UTC','YYYY-MM-DD') AS day, COUNT(*) FILTER(WHERE event_type='view')::int AS views, COUNT(*) FILTER(WHERE event_type='click')::int AS clicks FROM analytics_events WHERE bio_id=$1 AND created_at>NOW()-INTERVAL '14 days' GROUP BY day ORDER BY day",[bio.id]);
  res.json({totals:totals.rows[0],days:days.rows});
});
app.get("/api/bios/:id/messages", authRequired, async (req,res) => {
  const bio=await ownedBio(req,res,req.params.id); if(!bio) return;
  const q=await pool.query("SELECT id,sender_name,sender_email,message,is_read,created_at FROM contact_messages WHERE bio_id=$1 ORDER BY created_at DESC LIMIT 100",[bio.id]); res.json(q.rows);
});
app.get("/api/admin/summary", authRequired, adminRequired, async (_req,res) => {
  const q=await pool.query("SELECT (SELECT COUNT(*) FROM users)::int users,(SELECT COUNT(*) FROM bios)::int bios,(SELECT COUNT(*) FROM analytics_events WHERE event_type='view')::int views,(SELECT COUNT(*) FROM contact_messages)::int messages");
  res.json(q.rows[0]);
});
app.get("/api/admin/users", authRequired, adminRequired, async (_req,res) => {
  const q=await pool.query("SELECT id,email,display_name,role,created_at FROM users ORDER BY created_at DESC LIMIT 200"); res.json(q.rows);
});
app.get("/:slug", (req,res,next) => {
  if (req.params.slug.startsWith("api")) return next();
  res.sendFile(path.join(__dirname, "../public/index.html"));
});
app.use("/api", (_req,res)=>res.status(404).json({error:"API không tồn tại."}));
app.use((err,_req,res,_next)=>{ console.error(err); res.status(500).json({error:"Có lỗi máy chủ. Vui lòng thử lại."}); });
const port=Number(process.env.PORT)||3000;
initDb().then(()=>app.listen(port,()=>console.log(`HMKEY Bio Link Pro chạy tại ${process.env.BASE_URL||`http://localhost:${port}`}`))).catch(err=>{console.error("Không khởi tạo được database:",err);process.exit(1);});
