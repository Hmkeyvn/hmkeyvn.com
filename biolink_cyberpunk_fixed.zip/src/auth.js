const jwt = require("jsonwebtoken");
const COOKIE_NAME = "hmkey_token";
function signToken(user) {
  return jwt.sign({ id: String(user.id), role: user.role, email: user.email }, process.env.JWT_SECRET, { expiresIn: "7d" });
}
function authRequired(req, res, next) {
  const token = req.cookies?.[COOKIE_NAME] || (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ error: "Vui lòng đăng nhập." });
  try { req.user = jwt.verify(token, process.env.JWT_SECRET); next(); }
  catch { return res.status(401).json({ error: "Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại." }); }
}
function adminRequired(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Bạn không có quyền quản trị." });
  next();
}
module.exports = { COOKIE_NAME, signToken, authRequired, adminRequired };
