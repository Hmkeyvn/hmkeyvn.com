const $=s=>document.querySelector(s);let currentBio=null;
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600);}
async function getJson(url,opts={}){const r=await fetch(url,{credentials:"same-origin",...opts});const d=await r.json().catch(()=>({error:"Không đọc được dữ liệu."}));if(!r.ok)throw new Error(d.error||"Lỗi kết nối.");return d;}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function getSlug(){const p=location.pathname.split("/").filter(Boolean);return p[0]&&p[0]!=="index.html"?p[0]:new URLSearchParams(location.search).get("bio");}
async function loadBio(){
 const slug=getSlug();if(!slug){$("#loading").innerHTML='Chào mừng đến <b>HMKEY Bio Link Pro</b><br><a class="btn inline-btn" href="/register.html">Tạo trang Bio của bạn</a>';return;}
 try{currentBio=await getJson(`/api/bios/${encodeURIComponent(slug)}/public`);$("#loading").classList.add("hidden");$("#bio-card").classList.remove("hidden");
 document.title=`${currentBio.display_name} · HMKEY`;document.documentElement.style.setProperty("--accent",currentBio.accent_color||"#8b5cf6");
 $("#display-name").textContent=currentBio.display_name;$("#bio-text").textContent=currentBio.bio||"";$("#avatar").src=currentBio.avatar_url||"https://api.dicebear.com/9.x/bottts-neutral/svg?seed="+encodeURIComponent(currentBio.slug);$("#cover").style.backgroundImage=currentBio.cover_url?`linear-gradient(90deg,#08081255,#08081288),url("${currentBio.cover_url.replace(/["\\]/g,"")}")`:"";
 $("#links").innerHTML=currentBio.links.map(l=>`<a class="link-card" href="${escapeHtml(l.url)}" target="_blank" rel="noopener noreferrer" data-link="${l.id}"><span class="link-icon">${escapeHtml(l.icon||"🔗")}</span><span>${escapeHtml(l.title)}</span><span class="link-arrow">↗</span></a>`).join("")||'<p class="muted">Chưa có liên kết nào.</p>';
 $("#socials").innerHTML=currentBio.socials.map(s=>`<a href="${escapeHtml(s.url)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeHtml(s.platform)}">${escapeHtml(s.platform.slice(0,2).toUpperCase())}</a>`).join("");
 if(currentBio.music_url){$("#music-box").classList.remove("hidden");$("#music-title").textContent=currentBio.music_title||"Nhạc nền";$("#audio").src=currentBio.music_url;}
 $("#year").textContent=new Date().getFullYear();
 $("#links").addEventListener("click",e=>{const a=e.target.closest("[data-link]");if(a)getJson("/api/public/click",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({bio_id:currentBio.id,link_id:Number(a.dataset.link)})}).catch(()=>{});});
 }catch(e){$("#loading").textContent=e.message;}
}
$("#music-toggle")?.addEventListener("click",async()=>{const a=$("#audio");try{if(a.paused){await a.play();$("#music-toggle").textContent="Ⅱ";}else{a.pause();$("#music-toggle").textContent="▶";}}catch{toast("Không thể phát nhạc. Kiểm tra URL âm thanh.");}});
$("#qr-button")?.addEventListener("click",()=>{if(!currentBio)return;$("#qr-image").innerHTML=`<img alt="Mã QR Bio" width="220" height="220" src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(location.href)}">`;$("#qr-modal").classList.remove("hidden");});
$("#qr-close")?.addEventListener("click",()=>$("#qr-modal").classList.add("hidden"));$("#qr-modal")?.addEventListener("click",e=>{if(e.target.id==="qr-modal")e.currentTarget.classList.add("hidden");});
$("#share-button")?.addEventListener("click",async()=>{try{if(navigator.share)await navigator.share({title:document.title,url:location.href});else{await navigator.clipboard.writeText(location.href);toast("Đã sao chép liên kết Bio.");}}catch{}});
$("#contact-form")?.addEventListener("submit",async e=>{e.preventDefault();if(!currentBio)return;const f=new FormData(e.currentTarget);try{const d=await getJson("/api/public/contact",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({bio_id:currentBio.id,name:f.get("name"),email:f.get("email"),message:f.get("message")})});$("#contact-status").textContent=d.message;e.currentTarget.reset();}catch(err){$("#contact-status").textContent=err.message;}});
loadBio();
