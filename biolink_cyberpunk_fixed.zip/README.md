# HMKEY Bio Link Pro

Bio Link phong cách Cyberpunk, giao diện tiếng Việt, responsive, có tài khoản, nhiều Bio, quản trị, nhạc nền, QR, liên kết, form liên hệ và thống kê.

## Công nghệ
- Frontend: HTML, CSS, JavaScript thuần (nhẹ, không cần bundler).
- Backend: Node.js 20+, Express.
- Database: PostgreSQL 16.
- Bảo mật: bcryptjs, JWT trong cookie HttpOnly, Helmet, rate limit, kiểm tra URL và dữ liệu.

## 1. Cài đặt yêu cầu
Cài Node.js 20+ và Docker Desktop (hoặc PostgreSQL 16 riêng).

## 2. Cấu hình
1. Giải nén dự án.
2. Sao chép `.env.example` thành `.env`.
3. Đặt `JWT_SECRET` thành chuỗi ngẫu nhiên dài tối thiểu 32 ký tự.
4. Đặt mật khẩu PostgreSQL trong `.env` và `docker-compose.yml` giống nhau.
5. Đặt `ADMIN_EMAIL` thành email sẽ dùng làm tài khoản quản trị đầu tiên.

Ví dụ tạo secret:
- macOS/Linux: `openssl rand -hex 32`
- Windows PowerShell: `[Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))`

## 3. Chạy dự án
Trong thư mục dự án, mở terminal:

```bash
docker compose up -d db
npm install
npm start
```

Mở `http://localhost:3000`.

## 4. Tạo tài khoản quản trị
1. Đặt `ADMIN_EMAIL` trong `.env` trước khi chạy.
2. Mở `/register.html`, đăng ký bằng đúng email đó.
3. Đăng xuất rồi đăng nhập lại. Backend sẽ cấp quyền admin cho email khớp `ADMIN_EMAIL`.
4. Mở `/dashboard.html`.

Không để `ADMIN_EMAIL` là email mẫu khi triển khai thật. Chỉ người kiểm soát được cấu hình máy chủ mới được chọn email quản trị.

## 5. Đường dẫn Bio
Mỗi trang có slug riêng, ví dụ `http://localhost:3000/hmkey-123`. Trang mặc định ở `/` sẽ giới thiệu dịch vụ nếu không có slug.

## 6. Cấu hình nhạc
Trong Dashboard, nhập URL trực tiếp tới file âm thanh `.mp3`, `.ogg` hoặc định dạng được trình duyệt hỗ trợ. Trình duyệt thường chặn tự phát nhạc; người xem cần bấm nút phát. Chỉ dùng nhạc bạn có quyền sử dụng.

## 7. QR Code
QR được tạo bằng dịch vụ QR bên ngoài khi mở hộp thoại QR. Do đó URL trang được gửi tới dịch vụ đó để tạo ảnh. Nếu cần riêng tư/offline, hãy thay bằng thư viện QR chạy hoàn toàn trên trình duyệt.

## 8. Triển khai công khai
- Dùng HTTPS.
- Đổi mật khẩu PostgreSQL mặc định và đặt `COOKIE_SECURE=true`.
- Đặt `NODE_ENV=production`.
- Dùng reverse proxy (Nginx/Caddy) và giới hạn cổng PostgreSQL chỉ cho máy chủ ứng dụng.
- Sao lưu database định kỳ.
- Không commit `.env` lên Git.
- Cấu hình CSP nghiêm ngặt trước khi bật lại `Content-Security-Policy` trong Helmet.
- Đặt giới hạn dung lượng, quét file và CDN nếu bổ sung upload ảnh.
- Cân nhắc CAPTCHA cho form liên hệ khi website có lưu lượng lớn.

## 9. API chính
- `GET /api/health`
- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`
- `GET /api/me`
- `POST /api/bios`, `PATCH /api/bios/:id`, `DELETE /api/bios/:id`
- `GET /api/bios/:slug/public`
- `GET/POST /api/bios/:id/links`, `PATCH/DELETE /api/links/:id`
- `POST /api/public/click`, `POST /api/public/contact`
- `GET /api/bios/:id/analytics`, `GET /api/bios/:id/messages`
- `GET /api/admin/summary`, `GET /api/admin/users`

## 10. Giới hạn hiện tại
- Bản mẫu có quản trị hệ thống xem tổng quan và danh sách tài khoản; chưa có chức năng khóa/xóa tài khoản trong Admin.
- Liên kết mạng xã hội có bảng dữ liệu/API đọc nhưng giao diện dashboard chưa có form chỉnh sửa social links.
- Chưa có upload file trực tiếp; ảnh bìa/avatar/nhạc dùng URL HTTPS.
- Thống kê lượt xem ghi mỗi lần tải trang; chưa khử trùng lặp theo phiên/ngày.
- QR dùng dịch vụ ngoài; xem lưu ý ở mục 7.
- Chưa có xác minh email, quên mật khẩu qua email hoặc MFA. Nên bổ sung trước khi dùng cho cộng đồng lớn.
