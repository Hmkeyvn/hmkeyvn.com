-- Chay sau khi sao luu database. Co the chay nhieu lan an toan.
ALTER TABLE products ADD COLUMN IF NOT EXISTS file_original_name TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS file_name TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS file_original_name TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS keys_inventory_order_unique ON keys_inventory(order_id) WHERE order_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS orders_key_unique ON orders(key_id) WHERE key_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS download_logs (
 id BIGSERIAL PRIMARY KEY,
 order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 ip_address INET,
 user_agent TEXT NOT NULL DEFAULT '',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS download_logs_order_idx ON download_logs(order_id,created_at DESC);
CREATE TABLE IF NOT EXISTS sepay_webhook_events (
 transaction_id TEXT PRIMARY KEY,
 payload JSONB NOT NULL DEFAULT '{}'::jsonb,
 result TEXT NOT NULL DEFAULT 'received',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
