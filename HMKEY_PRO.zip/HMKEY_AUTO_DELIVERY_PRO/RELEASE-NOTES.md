# Release 2.1.0

- Thêm SePay webhook HMAC-SHA256 tương thích header `X-SePay-Timestamp` và `X-SePay-Signature`.
- Chặn webhook replay theo timestamp, kiểm tra đúng tài khoản nhận, giao dịch tiền vào, mã nạp và số tiền.
- Chống cộng ví hai lần bằng bảng `sepay_webhook_events` với transaction ID duy nhất.
- Lưu snapshot file trên từng đơn để thay file sản phẩm không làm mất link tải của đơn cũ.
- Bổ sung `/api/health`, script backup và health-check, mẫu Nginx.
- Cập nhật hướng dẫn Termius và checklist trước khi mở bán thật.

Validation đã chạy trong môi trường đóng gói: `npm run check` (Node.js syntax check) thành công. Chưa thể xác nhận kết nối PostgreSQL, domain, tài khoản ngân hàng hoặc SePay live vì các thông tin và dịch vụ đó thuộc VPS/tài khoản của chủ shop.
