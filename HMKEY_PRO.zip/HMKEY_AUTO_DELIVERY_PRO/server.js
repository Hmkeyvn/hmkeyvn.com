require('dotenv').config();
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
if (process.env.NODE_ENV === 'production') app.set('trust proxy', 1);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 15, idleTimeoutMillis: 30000 });
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
const PRIVATE_DIR = path.resolve(__dirname, 'private-files');
fs.mkdirSync(PRIVATE_DIR, { recursive: true, mode: 0o750 });
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error('SESSION_SECRET phải có ít nhất 32 ký tự. Hãy tạo file .env từ .env.example.'); process.exit(1);
}

// Chỉ cho phép tải file từ route đã xác thực; tuyệt đối không public private-files.
const allowedExt = new Set(['.zip','.rar','.7z','.exe','.msi','.apk','.pdf','.txt','.dmg']);
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, PRIVATE_DIR),
  filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase())
});
const upload = multer({
  storage,
  limits: { fileSize: Number(process.env.MAX_UPLOAD_BYTES || 1073741824), files: 1 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowedExt.has(ext)) return cb(new Error('Định dạng file chưa được cho phép. Hỗ trợ ZIP, RAR, 7Z, EXE, MSI, APK, PDF, TXT, DMG.'));
    cb(null, true);
  }
});

app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"], scriptSrc: ["'self'"],
  imgSrc: ["'self'", 'data:', 'https://img.vietqr.io'], connectSrc: ["'self'"]
}}}));

// SePay HMAC webhook: khai báo TRƯỚC express.json() để giữ nguyên raw body khi xác minh chữ ký.
app.post('/api/sepay/webhook', express.raw({ type: 'application/json', limit: '256kb' }), asyncRoute(async (req, res) => {
  const secret = process.env.SEPAY_WEBHOOK_SECRET || '';
  const timestamp = String(req.get('X-SePay-Timestamp') || '');
  const signature = String(req.get('X-SePay-Signature') || '');
  const ts = Number(timestamp);
  if (!secret || !Buffer.isBuffer(req.body) || !Number.isSafeInteger(ts) || Math.abs(Math.floor(Date.now()/1000)-ts) > 300) {
    return res.status(401).json({ success: false, message: 'Webhook authentication failed' });
  }
  const expected = 'sha256=' + crypto.createHmac('sha256', secret).update(`${timestamp}.${req.body.toString('utf8')}`).digest('hex');
  const a = Buffer.from(expected), b = Buffer.from(signature);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ success: false, message: 'Invalid signature' });
  let data;
  try { data = JSON.parse(req.body.toString('utf8')); } catch { return res.status(400).json({ success: false, message: 'Invalid JSON' }); }
  const transactionId = data && data.id != null ? String(data.id) : '';
  const amount = Number(data && data.transferAmount);
  if (!transactionId || !Number.isSafeInteger(amount) || amount <= 0) return res.status(400).json({ success: false, message: 'Invalid transaction fields' });
  if (String(data.transferType || '').toLowerCase() !== 'in') return res.status(200).json({ success: true, ignored: true });
  const configuredAccount = String(process.env.BANK_ACCOUNT || '').replace(/\s+/g, '');
  if (!configuredAccount) return res.status(503).json({ success: false, message: 'Bank account is not configured' });
  const incomingAccount = String(data.accountNumber || '').replace(/\s+/g, '');
  if (configuredAccount && incomingAccount !== configuredAccount) return res.status(200).json({ success: true, ignored: true });
  const prefix = String(process.env.SEPAY_TRANSFER_PREFIX || 'HMKEY').replace(/[^A-Z0-9]/gi, '');
  const pattern = new RegExp(`\\b${prefix}[A-F0-9]{12}\\b`, 'i');
  let code = typeof data.code === 'string' && pattern.test(data.code.trim()) ? data.code.trim().toUpperCase() : null;
  if (!code) { const match = String(data.content || data.description || '').match(pattern); code = match ? match[0].toUpperCase() : null; }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const event = await client.query(`INSERT INTO sepay_webhook_events(transaction_id,payload,result) VALUES($1,$2::jsonb,'received') ON CONFLICT(transaction_id) DO NOTHING RETURNING transaction_id`, [transactionId, JSON.stringify(data)]);
    if (!event.rowCount) { await client.query('COMMIT'); return res.status(200).json({ success: true, duplicate: true }); }
    if (!code) {
      await client.query(`UPDATE sepay_webhook_events SET result='no_payment_code' WHERE transaction_id=$1`, [transactionId]);
      await client.query('COMMIT'); return res.status(200).json({ success: true, ignored: true });
    }
    const paid = await client.query(`UPDATE deposits SET status='approved',provider_reference=$3,reviewed_at=now(),reviewed_by=NULL WHERE transfer_note=$1 AND amount=$2 AND status='pending' AND provider_reference IS NULL RETURNING user_id,amount,transfer_note`, [code, amount, transactionId]);
    if (paid.rowCount === 1) {
      const dep = paid.rows[0];
      const user = await client.query('SELECT balance FROM users WHERE id=$1 FOR UPDATE', [dep.user_id]);
      const balance = Number(user.rows[0].balance) + Number(dep.amount);
      await client.query('UPDATE users SET balance=$1 WHERE id=$2', [balance, dep.user_id]);
      await client.query(`INSERT INTO transactions(user_id,kind,amount,balance_after,reference,note) VALUES($1,'deposit',$2,$3,$4,$5)`, [dep.user_id, dep.amount, balance, `SEPAY:${transactionId}`, `Nạp tiền tự động ${dep.transfer_note}`]);
      await client.query(`UPDATE sepay_webhook_events SET result='credited' WHERE transaction_id=$1`, [transactionId]);
    } else {
      await client.query(`UPDATE sepay_webhook_events SET result='unmatched_or_amount_mismatch' WHERE transaction_id=$1`, [transactionId]);
    }
    await client.query('COMMIT');
    return res.status(200).json({ success: true });
  } catch (err) { await client.query('ROLLBACK'); throw err; }
  finally { client.release(); }
}));

app.use(express.json({ limit: '32kb' }));
app.use(express.urlencoded({ extended: false, limit: '16kb' }));
app.use(session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false, name: 'hmkey.sid',
  cookie: { httpOnly: true, sameSite: 'lax', secure: isProd, maxAge: 1000*60*60*8 }
}));
app.use('/api', rateLimit({ windowMs: 15*60*1000, limit: 300, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));
const safeUser = u => ({ id: u.id, email: u.email, role: u.role, balance: Number(u.balance) });
const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
function requireAuth(req,res,next){ if(!req.session.userId) return res.status(401).json({error:'Vui lòng đăng nhập.'}); next(); }
async function currentUser(req){ if(!req.session.userId) return null; const r=await pool.query('SELECT id,email,role,balance FROM users WHERE id=$1',[req.session.userId]); return r.rows[0]||null; }
function requireAdmin(req,res,next){ currentUser(req).then(u=>{ if(!u||u.role!=='admin') return res.status(403).json({error:'Bạn không có quyền quản trị.'}); req.user=u; next(); }).catch(next); }
function privateFilePath(fileName) {
  if (!fileName || path.basename(fileName) !== fileName) return null;
  const full = path.resolve(PRIVATE_DIR, fileName);
  return full.startsWith(PRIVATE_DIR + path.sep) ? full : null;
}

app.get('/api/health', asyncRoute(async (_req,res)=>{await pool.query('SELECT 1');res.json({ok:true,service:'hmkey-store'});}));
app.get('/api/config', (_req,res)=>res.json({storeName:process.env.STORE_NAME||'Hmkey'}));
app.post('/api/register', rateLimit({windowMs:60*60*1000,limit:10}), asyncRoute(async(req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
 if(!/^\S+@\S+\.\S+$/.test(email)||email.length>254) return res.status(400).json({error:'Email không hợp lệ.'});
 if(password.length<10||password.length>72) return res.status(400).json({error:'Mật khẩu phải từ 10 đến 72 ký tự.'});
 const hash=await bcrypt.hash(password,12);
 try { const r=await pool.query('INSERT INTO users(email,password_hash) VALUES($1,$2) RETURNING id,email,role,balance',[email,hash]); req.session.userId=r.rows[0].id; res.json({user:safeUser(r.rows[0])}); }
 catch(e){if(e.code==='23505') return res.status(409).json({error:'Email đã được đăng ký.'}); throw e;}
}));
app.post('/api/login', rateLimit({windowMs:15*60*1000,limit:12}), asyncRoute(async(req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
 const r=await pool.query('SELECT * FROM users WHERE email=$1',[email]);
 if(!r.rowCount||!(await bcrypt.compare(password,r.rows[0].password_hash))) return res.status(401).json({error:'Email hoặc mật khẩu không đúng.'});
 req.session.regenerate(err=>{if(err) return res.status(500).json({error:'Không tạo được phiên đăng nhập.'}); req.session.userId=r.rows[0].id; res.json({user:safeUser(r.rows[0])});});
}));
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',asyncRoute(async(req,res)=>{const u=await currentUser(req);res.json({user:u?safeUser(u):null});}));

app.get('/api/products',asyncRoute(async(_req,res)=>{
 const r=await pool.query(`SELECT p.id,p.name,p.description,p.price,p.category,
 (SELECT count(*) FROM keys_inventory k WHERE k.product_id=p.id AND k.order_id IS NULL) AS stock,
 (p.file_name IS NOT NULL) AS has_file FROM products p WHERE p.active=true ORDER BY p.id DESC`);
 res.json({products:r.rows.map(p=>({...p,price:Number(p.price),stock:Number(p.stock)}))});
}));
app.get('/api/orders',requireAuth,asyncRoute(async(req,res)=>{
 const r=await pool.query(`SELECT o.id,o.amount,o.status,o.created_at,p.name,COALESCE(o.file_original_name,p.file_original_name) AS file_original_name,
 k.key_value,(COALESCE(o.file_name,p.file_name) IS NOT NULL) AS has_download
 FROM orders o JOIN products p ON p.id=o.product_id
 LEFT JOIN keys_inventory k ON k.id=o.key_id
 WHERE o.user_id=$1 ORDER BY o.id DESC`,[req.session.userId]);
 res.json({orders:r.rows.map(o=>({...o,amount:Number(o.amount),download_url:o.has_download?`/api/orders/${o.id}/download`:null}))});
}));
app.get('/api/transactions',requireAuth,asyncRoute(async(req,res)=>{const r=await pool.query('SELECT id,kind,amount,balance_after,reference,note,created_at FROM transactions WHERE user_id=$1 ORDER BY id DESC LIMIT 200',[req.session.userId]);res.json({transactions:r.rows.map(t=>({...t,amount:Number(t.amount),balance_after:Number(t.balance_after)}))});}));
app.post('/api/deposits',requireAuth,asyncRoute(async(req,res)=>{
 const amount=Number(req.body.amount); if(!Number.isSafeInteger(amount)||amount<10000||amount>50000000) return res.status(400).json({error:'Số tiền nạp phải từ 10.000 đến 50.000.000 VNĐ.'});
 const note='HMKEY'+crypto.randomBytes(6).toString('hex').toUpperCase();
 const r=await pool.query('INSERT INTO deposits(user_id,amount,transfer_note) VALUES($1,$2,$3) RETURNING id,amount,transfer_note,status,created_at',[req.session.userId,amount,note]);
 const cfg={bankName:process.env.BANK_NAME||'',bankAccount:process.env.BANK_ACCOUNT||'',bankAccountName:process.env.BANK_ACCOUNT_NAME||''};
 let qrUrl=null; if(cfg.bankAccount&&cfg.bankName) qrUrl=`https://img.vietqr.io/image/${encodeURIComponent(cfg.bankName)}-${encodeURIComponent(cfg.bankAccount)}-compact2.png?amount=${amount}&addInfo=${encodeURIComponent(note)}&accountName=${encodeURIComponent(cfg.bankAccountName)}`;
 res.json({deposit:r.rows[0],qrUrl,bank:cfg,message:process.env.SEPAY_WEBHOOK_SECRET?'Đang chờ SePay xác nhận giao dịch. Số dư chỉ được cộng khi webhook hợp lệ và đúng số tiền.':'Yêu cầu đang chờ Admin xác minh thủ công. Số dư chưa được cộng.'});
}));
app.get('/api/deposits',requireAuth,asyncRoute(async(req,res)=>{const r=await pool.query('SELECT id,amount,transfer_note,status,created_at,reviewed_at FROM deposits WHERE user_id=$1 ORDER BY id DESC LIMIT 100',[req.session.userId]);res.json({deposits:r.rows.map(d=>({...d,amount:Number(d.amount)}))});}));

// Mua hàng atomic: khóa số dư + khóa đúng một key + tạo đơn + gắn key trong cùng transaction.
app.post('/api/products/:id/buy',requireAuth,asyncRoute(async(req,res)=>{
 const client=await pool.connect(); let committed=false;
 try {
  await client.query('BEGIN');
  const u=await client.query('SELECT id,balance FROM users WHERE id=$1 FOR UPDATE',[req.session.userId]);
  const p=await client.query('SELECT * FROM products WHERE id=$1 AND active=true FOR UPDATE',[req.params.id]);
  if(!p.rowCount){await client.query('ROLLBACK');return res.status(404).json({error:'Sản phẩm không tồn tại.'});}
  const product=p.rows[0], price=Number(product.price), filePath=privateFilePath(product.file_name);
  if(!filePath || !fs.existsSync(filePath)){await client.query('ROLLBACK');return res.status(409).json({error:'Sản phẩm chưa có file tải. Admin cần tải file lên trước khi mở bán.'});}
  if(Number(u.rows[0].balance)<price){await client.query('ROLLBACK');return res.status(400).json({error:'Số dư không đủ. Vui lòng nạp tiền.'});}
  const k=await client.query('SELECT id,key_value FROM keys_inventory WHERE product_id=$1 AND order_id IS NULL ORDER BY id FOR UPDATE SKIP LOCKED LIMIT 1',[product.id]);
  if(!k.rowCount){await client.query('ROLLBACK');return res.status(409).json({error:'Sản phẩm tạm hết key. Vui lòng quay lại sau.'});}
  const bal=Number(u.rows[0].balance)-price;
  await client.query('UPDATE users SET balance=$1 WHERE id=$2',[bal,req.session.userId]);
  const o=await client.query("INSERT INTO orders(user_id,product_id,amount,status,key_id,file_name,file_original_name) VALUES($1,$2,$3,'completed',$4,$5,$6) RETURNING id",[req.session.userId,product.id,price,k.rows[0].id,path.basename(product.file_name),path.basename(product.file_original_name || 'HMKEY-download'+path.extname(product.file_name))]);
  await client.query('UPDATE keys_inventory SET order_id=$1 WHERE id=$2',[o.rows[0].id,k.rows[0].id]);
  await client.query('INSERT INTO transactions(user_id,kind,amount,balance_after,reference,note) VALUES($1,\'purchase\',$2,$3,$4,$5)',[req.session.userId,-price,bal,String(o.rows[0].id),'Mua '+product.name]);
  await client.query('COMMIT'); committed=true;
  res.json({ok:true,orderId:o.rows[0].id,key:k.rows[0].key_value,balance:bal,downloadUrl:`/api/orders/${o.rows[0].id}/download`,message:'Đã giao key và link tải. Bạn có thể tải lại không giới hạn khi đăng nhập đúng tài khoản.'});
 } catch(e){if(!committed) await client.query('ROLLBACK');throw e;} finally{client.release();}
}));

// Unlimited downloads: no download counter/limit; every request still checks owner + completed order.
app.get('/api/orders/:id/download',requireAuth,asyncRoute(async(req,res)=>{
 const r=await pool.query(`SELECT o.id,o.user_id,o.status,COALESCE(o.file_name,p.file_name) AS file_name,
 COALESCE(o.file_original_name,p.file_original_name) AS file_original_name
 FROM orders o JOIN products p ON p.id=o.product_id WHERE o.id=$1 AND o.user_id=$2`,[req.params.id,req.session.userId]);
 if(!r.rowCount || r.rows[0].status!=='completed')return res.status(404).json({error:'Không tìm thấy đơn hàng hợp lệ hoặc bạn không có quyền tải.'});
 const order=r.rows[0], full=privateFilePath(order.file_name);
 if(!full || !fs.existsSync(full))return res.status(404).json({error:'File tải hiện không tồn tại. Vui lòng liên hệ hỗ trợ.'});
 await pool.query('INSERT INTO download_logs(order_id,user_id,ip_address,user_agent) VALUES($1,$2,$3,$4)',[order.id,req.session.userId,req.ip,String(req.get('user-agent')||'').slice(0,500)]);
 res.download(full, path.basename(order.file_original_name || 'HMKEY-download'+path.extname(full)));
}));

// Bootstrap Admin: chỉ chạy khi chưa có admin. Sau khi tạo xong, bỏ ADMIN_PASSWORD khỏi .env.
app.post('/api/admin/login-bootstrap', rateLimit({windowMs:60*60*1000,limit:5}), asyncRoute(async(req,res)=>{
 const count=await pool.query("SELECT count(*)::int AS n FROM users WHERE role='admin'");
 if(count.rows[0].n>0)return res.status(403).json({error:'Admin đã được khởi tạo.'});
 const email=String(process.env.ADMIN_EMAIL||'').toLowerCase(), password=String(process.env.ADMIN_PASSWORD||'');
 if(!email||password.length<14)return res.status(500).json({error:'Hãy cấu hình ADMIN_EMAIL và ADMIN_PASSWORD mạnh trong .env.'});
 const hash=await bcrypt.hash(password,12); const r=await pool.query("INSERT INTO users(email,password_hash,role) VALUES($1,$2,'admin') RETURNING id,email,role,balance",[email,hash]);
 req.session.userId=r.rows[0].id;res.json({user:safeUser(r.rows[0]),message:'Đã tạo Admin. Hãy xóa ADMIN_PASSWORD khỏi .env và khởi động lại.'});
}));
app.get('/api/admin/summary',requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
 const [users,orders,deposits,products,downloads]=await Promise.all([
  pool.query('SELECT count(*)::int n FROM users'),pool.query('SELECT count(*)::int n,COALESCE(sum(amount),0)::bigint revenue FROM orders'),
  pool.query("SELECT count(*)::int n FROM deposits WHERE status='pending'"),pool.query('SELECT count(*)::int n FROM products'),pool.query('SELECT count(*)::int n FROM download_logs')
 ]);
 res.json({users:users.rows[0].n,orders:orders.rows[0].n,revenue:Number(orders.rows[0].revenue),pendingDeposits:deposits.rows[0].n,products:products.rows[0].n,downloads:downloads.rows[0].n});
}));
app.get('/api/admin/products',requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
 const r=await pool.query(`SELECT p.*, (SELECT count(*) FROM keys_inventory k WHERE k.product_id=p.id AND k.order_id IS NULL) stock FROM products p ORDER BY id DESC`);
 res.json({products:r.rows.map(p=>({...p,price:Number(p.price),stock:Number(p.stock),has_file:!!p.file_name}))});
}));
app.post('/api/admin/products',requireAuth,requireAdmin,upload.single('downloadFile'),asyncRoute(async(req,res)=>{
 const {name,description='',category='Phần mềm'}=req.body;const price=Number(req.body.price);
 if(!String(name||'').trim()||!Number.isSafeInteger(price)||price<0){if(req.file)fs.rmSync(req.file.path,{force:true});return res.status(400).json({error:'Tên và giá sản phẩm không hợp lệ.'});}
 const r=await pool.query('INSERT INTO products(name,description,price,category,file_name,file_original_name) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',[
  String(name).trim(),String(description).slice(0,2000),price,String(category).slice(0,80),req.file?path.basename(req.file.filename):null,req.file?path.basename(req.file.originalname):null
 ]);
 await pool.query('INSERT INTO audit_log(actor_id,action,target,details) VALUES($1,$2,$3,$4)',[req.user.id,'product.create',String(r.rows[0].id),JSON.stringify({name})]);
 res.json({product:r.rows[0]});
}));
app.post('/api/admin/products/:id/file',requireAuth,requireAdmin,upload.single('downloadFile'),asyncRoute(async(req,res)=>{
 if(!req.file)return res.status(400).json({error:'Chưa chọn file tải.'});
 const old=await pool.query('SELECT file_name FROM products WHERE id=$1',[req.params.id]);
 if(!old.rowCount){fs.rmSync(req.file.path,{force:true});return res.status(404).json({error:'Không tìm thấy sản phẩm.'});}
 await pool.query('UPDATE products SET file_name=$1,file_original_name=$2 WHERE id=$3',[path.basename(req.file.filename),path.basename(req.file.originalname),req.params.id]);
 // Giữ file cũ nếu đơn hàng trước đó còn tham chiếu; không làm hỏng quyền tải của khách đã mua.
 const oldPath=privateFilePath(old.rows[0].file_name);
 if(oldPath&&fs.existsSync(oldPath)){const used=await pool.query('SELECT 1 FROM orders WHERE file_name=$1 LIMIT 1',[old.rows[0].file_name]);if(!used.rowCount)fs.rmSync(oldPath,{force:true});}
 await pool.query('INSERT INTO audit_log(actor_id,action,target,details) VALUES($1,$2,$3,$4)',[req.user.id,'product.file.upload',String(req.params.id),JSON.stringify({originalName:req.file.originalname,size:req.file.size})]);
 res.json({ok:true,fileName:req.file.originalname,message:'Đã lưu file riêng tư trên VPS.'});
}));
app.patch('/api/admin/products/:id',requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
 const {name,description,category,active}=req.body;const price=req.body.price===undefined?null:Number(req.body.price);
 if(price!==null&&(!Number.isSafeInteger(price)||price<0))return res.status(400).json({error:'Giá không hợp lệ.'});
 const r=await pool.query(`UPDATE products SET name=COALESCE($1,name),description=COALESCE($2,description),category=COALESCE($3,category),active=COALESCE($4,active),price=COALESCE($5,price) WHERE id=$6 RETURNING *`,[name||null,description===undefined?null:String(description).slice(0,2000),category||null,typeof active==='boolean'?active:null,price,req.params.id]);
 if(!r.rowCount)return res.status(404).json({error:'Không tìm thấy sản phẩm.'});res.json({product:r.rows[0]});
}));
app.post('/api/admin/products/:id/keys',requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
 const keys=String(req.body.keys||'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);if(!keys.length||keys.length>500)return res.status(400).json({error:'Nhập từ 1 đến 500 key, mỗi dòng một key.'});
 const p=await pool.query('SELECT id FROM products WHERE id=$1',[req.params.id]);if(!p.rowCount)return res.status(404).json({error:'Sản phẩm không tồn tại.'});
 const client=await pool.connect();let inserted=0;try{await client.query('BEGIN');for(const key of keys){const x=await client.query('INSERT INTO keys_inventory(product_id,key_value) VALUES($1,$2) ON CONFLICT(key_value) DO NOTHING',[req.params.id,key]);inserted+=x.rowCount;}await client.query('COMMIT');res.json({ok:true,received:keys.length,inserted,duplicates:keys.length-inserted});}catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
}));
app.get('/api/admin/deposits',requireAuth,requireAdmin,asyncRoute(async(req,res)=>{const r=await pool.query('SELECT d.*,u.email FROM deposits d JOIN users u ON u.id=d.user_id ORDER BY d.id DESC LIMIT 300');res.json({deposits:r.rows.map(d=>({...d,amount:Number(d.amount)}))});}));
app.post('/api/admin/deposits/:id/review',requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
 const decision=req.body.decision;if(!['approve','reject'].includes(decision))return res.status(400).json({error:'Quyết định không hợp lệ.'});
 const client=await pool.connect();try{await client.query('BEGIN');const d=await client.query('SELECT * FROM deposits WHERE id=$1 FOR UPDATE',[req.params.id]);if(!d.rowCount){await client.query('ROLLBACK');return res.status(404).json({error:'Không tìm thấy yêu cầu nạp.'});}if(d.rows[0].status!=='pending'){await client.query('ROLLBACK');return res.status(409).json({error:'Yêu cầu này đã được xử lý.'});}
 const dep=d.rows[0];if(decision==='approve') {const u=await client.query('SELECT balance FROM users WHERE id=$1 FOR UPDATE',[dep.user_id]);const bal=Number(u.rows[0].balance)+Number(dep.amount);await client.query('UPDATE users SET balance=$1 WHERE id=$2',[bal,dep.user_id]);await client.query("INSERT INTO transactions(user_id,kind,amount,balance_after,reference,note) VALUES($1,'deposit',$2,$3,$4,$5)",[dep.user_id,dep.amount,bal,String(dep.id),'Nạp tiền được Admin xác minh']);}
 await client.query('UPDATE deposits SET status=$1,reviewed_by=$2,reviewed_at=now() WHERE id=$3',[decision==='approve'?'approved':'rejected',req.user.id,dep.id]);await client.query('INSERT INTO audit_log(actor_id,action,target,details) VALUES($1,$2,$3,$4)',[req.user.id,'deposit.'+decision,String(dep.id),JSON.stringify({amount:dep.amount,userId:dep.user_id})]);await client.query('COMMIT');res.json({ok:true});
 }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
}));
app.get('/api/admin/orders',requireAuth,requireAdmin,asyncRoute(async(req,res)=>{const r=await pool.query('SELECT o.*,u.email,p.name product_name FROM orders o JOIN users u ON u.id=o.user_id JOIN products p ON p.id=o.product_id ORDER BY o.id DESC LIMIT 500');res.json({orders:r.rows.map(o=>({...o,amount:Number(o.amount)}))});}));
app.use('/api',(req,res)=>res.status(404).json({error:'Không tìm thấy API.'}));
app.use((err,req,res,next)=>{console.error(err);if(res.headersSent)return next(err);if(err instanceof multer.MulterError){return res.status(400).json({error:err.code==='LIMIT_FILE_SIZE'?'File vượt quá dung lượng cho phép.':'Lỗi tải file.'});}res.status(err.status && err.status >= 400 && err.status < 500 ? err.status : 500).json({error:err.status && err.status < 500 ? (err.message||'Dữ liệu không hợp lệ.') : 'Lỗi máy chủ. Vui lòng thử lại.'});});
app.listen(PORT,()=>console.log(`HMKEY KEY STORE PRO chạy tại http://localhost:${PORT}`));
