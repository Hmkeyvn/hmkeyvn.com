-- HMKEY KEY STORE PRO. Chạy trên DB hmkey hiện tại hoặc DB mới.
CREATE TABLE IF NOT EXISTS users (
 id BIGSERIAL PRIMARY KEY, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','admin')),
 balance BIGINT NOT NULL DEFAULT 0 CHECK (balance >= 0), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS products (
 id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
 price BIGINT NOT NULL CHECK (price >= 0), category TEXT NOT NULL DEFAULT 'Ứng dụng',
 active BOOLEAN NOT NULL DEFAULT true, file_name TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE products ADD COLUMN IF NOT EXISTS file_original_name TEXT;
CREATE TABLE IF NOT EXISTS keys_inventory (
 id BIGSERIAL PRIMARY KEY, product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
 key_value TEXT NOT NULL, order_id BIGINT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS keys_inventory_key_unique ON keys_inventory(key_value);
CREATE TABLE IF NOT EXISTS orders (
 id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id), product_id BIGINT NOT NULL REFERENCES products(id),
 amount BIGINT NOT NULL CHECK (amount >= 0), status TEXT NOT NULL DEFAULT 'completed', key_id BIGINT REFERENCES keys_inventory(id),
 file_name TEXT, file_original_name TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS file_name TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS file_original_name TEXT;
DO $$ BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'keys_inventory_order_fk') THEN
  ALTER TABLE keys_inventory ADD CONSTRAINT keys_inventory_order_fk FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL;
 END IF;
END $$;
CREATE UNIQUE INDEX IF NOT EXISTS keys_inventory_order_unique ON keys_inventory(order_id) WHERE order_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS orders_key_unique ON orders(key_id) WHERE key_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS deposits (
 id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id), amount BIGINT NOT NULL CHECK (amount > 0),
 transfer_note TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 provider_reference TEXT UNIQUE, reviewed_by BIGINT REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now(), reviewed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS transactions (
 id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id), kind TEXT NOT NULL CHECK(kind IN ('deposit','purchase','adjustment')),
 amount BIGINT NOT NULL, balance_after BIGINT NOT NULL, reference TEXT, note TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_log (
 id BIGSERIAL PRIMARY KEY, actor_id BIGINT REFERENCES users(id), action TEXT NOT NULL, target TEXT NOT NULL DEFAULT '',
 details JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS download_logs (
 id BIGSERIAL PRIMARY KEY, order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, ip_address INET, user_agent TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS orders_user_created_idx ON orders(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS keys_product_available_idx ON keys_inventory(product_id,id) WHERE order_id IS NULL;
CREATE INDEX IF NOT EXISTS download_logs_order_idx ON download_logs(order_id,created_at DESC);
INSERT INTO products(name,description,price,category,active)
SELECT 'Counter-Strike 2 - Key mẫu','Sản phẩm mẫu. Admin cần upload file và nhập key thật trước khi mở bán.',50000,'Counter-Strike 2',false
WHERE NOT EXISTS (SELECT 1 FROM products);


-- Idempotency log for SePay webhook events (prevents double credit on retries/replays).
CREATE TABLE IF NOT EXISTS sepay_webhook_events (
 transaction_id TEXT PRIMARY KEY,
 payload JSONB NOT NULL DEFAULT '{}'::jsonb,
 result TEXT NOT NULL DEFAULT 'received',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
