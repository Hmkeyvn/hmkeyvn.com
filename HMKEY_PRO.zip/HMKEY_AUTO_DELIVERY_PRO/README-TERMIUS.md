# HMKEY AUTO DELIVERY PRO 2.1.0 — Cài trên VPS bằng Termius

Hỗ trợ Ubuntu 22.04/24.04 hoặc Debian 12, Node.js 20+, PostgreSQL, Nginx, PM2.

## 1) Cài môi trường
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl ca-certificates gnupg postgresql postgresql-contrib nginx unzip
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm install -g pm2
node -v && npm -v
```

## 2) Upload ZIP bằng Termius SFTP
Upload `HMKEY_AUTO_DELIVERY_PRO.zip` vào `/var/www/`.
```bash
sudo mkdir -p /var/www/hmkey
sudo chown -R $USER:$USER /var/www/hmkey
cd /var/www/hmkey
unzip HMKEY_AUTO_DELIVERY_PRO.zip
cd HMKEY_AUTO_DELIVERY_PRO
```
Nếu thư mục đã có source cũ, hãy sao lưu trước khi thay thế.

## 3) PostgreSQL
Nếu chưa có role/database:
```bash
sudo -u postgres psql
```
```sql
CREATE USER hmkey_user WITH PASSWORD 'MAT_KHAU_DB_RAT_MANH';
CREATE DATABASE hmkey OWNER hmkey_user;
\q
```
Nếu đã tồn tại, không tạo trùng; xác nhận role có quyền trên DB `hmkey`.

## 4) Cấu hình môi trường
```bash
cp .env.example .env
nano .env
```
Sửa tối thiểu:
- `DATABASE_URL=postgres://hmkey_user:MAT_KHAU_DB@127.0.0.1:5432/hmkey`
- `SESSION_SECRET`: tạo bằng `openssl rand -base64 48`
- `ADMIN_EMAIL` và `ADMIN_PASSWORD` (ít nhất 14 ký tự, riêng biệt).
- `BANK_NAME=BIDV`, `BANK_ACCOUNT`, `BANK_ACCOUNT_NAME` đúng tài khoản nhận tiền.
- `SEPAY_TRANSFER_PREFIX=HMKEY`.
- `SEPAY_WEBHOOK_SECRET`: Secret Key HMAC do SePay cấp khi tạo webhook.

Không gửi `.env`, mật khẩu database hoặc secret qua chat. Không commit `.env` lên GitHub.

## 5) Cài và cập nhật database
```bash
npm install
npm run check
PGPASSWORD='MAT_KHAU_DB' psql -h 127.0.0.1 -U hmkey_user -d hmkey -v ON_ERROR_STOP=1 -f schema.sql
mkdir -p private-files
chmod 750 private-files
```
Trước khi áp dụng schema vào DB đang có dữ liệu thật, sao lưu trước:
```bash
sudo -u postgres pg_dump hmkey > ~/hmkey-before-update-$(date +%F-%H%M).sql
```
Schema sử dụng `IF NOT EXISTS` và `ADD COLUMN IF NOT EXISTS` để cập nhật các bảng/cột mới, gồm snapshot file trên đơn hàng và log webhook SePay.

## 6) Tạo Admin lần đầu
Khởi động tạm:
```bash
npm start
```
Mở terminal thứ hai:
```bash
curl -i -X POST http://127.0.0.1:3000/api/admin/login-bootstrap
```
Đăng nhập bằng email/mật khẩu Admin. Ngay sau khi tạo thành công, xóa `ADMIN_PASSWORD` khỏi `.env` rồi restart app. Endpoint bootstrap tự khóa sau khi đã có Admin.

## 7) Cấu hình SePay tự động nạp ví
1. Đăng nhập SePay, liên kết đúng tài khoản ngân hàng nhận tiền.
2. Trong Dashboard SePay → Webhooks → Thêm webhook.
3. URL nhận webhook: `https://TEN-MIEN-CUA-BAN/api/sepay/webhook`.
4. Chọn sự kiện **Tiền vào**, định dạng JSON, xác thực **HMAC-SHA256**.
5. Đặt tiền tố mã thanh toán `HMKEY` (phải khớp `SEPAY_TRANSFER_PREFIX`). Bật lọc mã nếu tùy chọn này có sẵn.
6. Sao chép Secret Key HMAC vào `SEPAY_WEBHOOK_SECRET` trong `.env`; không chia sẻ secret.
7. Restart app, dùng chức năng **Gửi thử** trên SePay và kiểm tra log. Sau đó thử một giao dịch nhỏ thật.

Webhook chỉ cộng tiền khi tất cả điều kiện đúng: chữ ký HMAC hợp lệ, timestamp trong 5 phút, đúng tài khoản nhận (nếu đã cấu hình), tiền vào, mã nạp đúng, số tiền khớp tuyệt đối, yêu cầu còn pending và ID giao dịch chưa từng xử lý. Webhook lặp lại không cộng tiền lần hai.

Nếu chưa cấu hình SePay hoặc secret chưa đúng, hệ thống không tự cộng tiền; Admin phải xác minh giao dịch thực nhận trước khi duyệt thủ công.

Tài liệu SePay: https://developer.sepay.vn/vi/sepay-webhooks/tich-hop-webhook và https://developer.sepay.vn/vi/sepay-webhooks/xac-thuc

## 8) Chạy 24/7
```bash
pm2 start server.js --name hmkey-store
pm2 save
pm2 startup
```
Chạy chính xác lệnh `sudo ...` mà `pm2 startup` in ra. Kiểm tra:
```bash
pm2 status
pm2 logs hmkey-store --lines 100
curl -s http://127.0.0.1:3000/api/health
```

## 9) Nginx + HTTPS
Tạo `/etc/nginx/sites-available/hmkey`:
```nginx
server {
  listen 80;
  server_name TEN-MIEN-CUA-BAN www.TEN-MIEN-CUA-BAN;
  client_max_body_size 1024m;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 300s;
  }
}
```
```bash
sudo ln -s /etc/nginx/sites-available/hmkey /etc/nginx/sites-enabled/hmkey
sudo nginx -t && sudo systemctl reload nginx
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d TEN-MIEN-CUA-BAN -d www.TEN-MIEN-CUA-BAN
```
Domain phải trỏ đúng IP VPS; mở firewall 80/443. Không mở port 3000 ra Internet.

## 10) Chuẩn bị sản phẩm và giao hàng
1. Đăng nhập Admin.
2. Tạo sản phẩm và đặt giá.
3. Upload file tải lên VPS, nhập đúng ID sản phẩm.
4. Dán KEY thật, mỗi dòng một KEY, vào kho sản phẩm.
5. Kiểm tra số KEY còn lại và file tải; chỉ mở bán sau khi đủ cả hai.
6. Dùng tài khoản khách thử nạp, mua, kiểm tra KEY và tải file.

Mỗi đơn hàng giữ snapshot file tại thời điểm mua. File cũ được giữ lại nếu đơn hàng cũ còn tham chiếu, tránh làm hỏng link tải của khách đã mua. File nằm trong `private-files/`, ngoài thư mục public. Mỗi lượt tải xác thực session, chủ đơn và trạng thái đơn; tải lại không giới hạn khi đơn còn hợp lệ.

## 11) Sao lưu
```bash
sudo -u postgres pg_dump hmkey > ~/hmkey-$(date +%F).sql
 tar -czf ~/hmkey-private-files-$(date +%F).tar.gz /var/www/hmkey/HMKEY_AUTO_DELIVERY_PRO/private-files
```
Giữ bản sao lưu ở nơi an toàn khác VPS. Database có thông tin tài khoản, số dư, đơn hàng và KEY; thư mục private-files chứa file giao cho khách.

## 12) Kiểm tra trước khi nhận tiền thật
- `npm run check` chạy không lỗi.
- `/api/health` trả `{"ok":true,...}`.
- Admin bootstrap đã hoàn tất và `ADMIN_PASSWORD` đã bỏ khỏi `.env`.
- HTTPS hoạt động, port 3000 không public.
- Webhook SePay HMAC gửi thử thành công; thử giao dịch thật giá trị nhỏ.
- Test webhook trùng ID không cộng tiền lần hai.
- Test khách mua: trừ đúng tiền, một KEY chỉ cấp cho một đơn, link tải yêu cầu đúng tài khoản.
- Đã sao lưu DB và `private-files`.

**Gói mã nguồn không thể tự kết nối tài khoản SePay, ngân hàng, domain hay VPS của bạn. Việc triển khai live chỉ hoàn tất sau khi bạn điền thông tin riêng, cấu hình SePay dashboard và chạy các bài kiểm thử trên VPS thật.**
