# HMKEY AUTO DELIVERY PRO 2.1.0

Website bán sản phẩm số/key, giao key + file tải riêng tư sau khi thanh toán bằng ví; có tích hợp webhook SePay HMAC cho nạp tiền tự động vào ví.

## Đã có trong mã nguồn
- Giao diện tiếng Việt, nền sáng, responsive.
- Đăng ký/đăng nhập/đăng xuất; session lưu PostgreSQL; mật khẩu băm bcrypt.
- Cửa hàng, danh mục, giá, số lượng KEY và trạng thái file.
- Ví VNĐ, tạo yêu cầu nạp tiền và QR VietQR.
- Nạp tiền thủ công qua Admin hoặc tự động qua SePay HMAC (sau khi cấu hình).
- Chống cộng tiền trùng bằng transaction ID duy nhất; kiểm tra tiền vào, tài khoản nhận, mã nạp và số tiền chính xác.
- Mua hàng bằng ví: khóa số dư + khóa 1 KEY chưa bán + tạo đơn + trừ tiền trong cùng PostgreSQL transaction.
- Giao KEY + link tải ngay khi đơn hoàn tất.
- File lưu ngoài thư mục public; tải yêu cầu đăng nhập đúng tài khoản sở hữu đơn.
- Không giới hạn số lượt tải; có log tải.
- File của đơn cũ được giữ nguyên khi Admin thay file sản phẩm.
- Admin: dashboard, sản phẩm, upload file, nhập hàng loạt KEY, duyệt/từ chối nạp tiền, xem đơn và thống kê.
- Health endpoint: `/api/health`.

## Cần cấu hình trước khi mở bán thật
1. VPS, domain, HTTPS, PostgreSQL và file `.env` hợp lệ.
2. Thông tin ngân hàng nhận tiền chính xác.
3. Nếu dùng SePay: tài khoản ngân hàng phải được liên kết trên SePay; tạo webhook HMAC-SHA256 đến `https://TEN-MIEN/api/sepay/webhook`; điền `SEPAY_WEBHOOK_SECRET`; gửi thử webhook thành công.
4. Tạo Admin lần đầu rồi xóa `ADMIN_PASSWORD` khỏi `.env`.
5. Tạo sản phẩm, upload file, nhập KEY thật; kiểm tra tồn kho trước khi mở bán.
6. Kiểm thử bằng tài khoản khách và giao dịch test nhỏ trước khi nhận tiền thật.

**Không có API key SePay, thông tin tài khoản ngân hàng, domain/VPS hoặc xác nhận webhook thật của chủ shop trong gói mã nguồn. Vì vậy không thể đánh dấu thanh toán live đã được kết nối sẵn.** Nếu chưa cấu hình SePay, yêu cầu nạp tiền sẽ chờ Admin xác minh thủ công; tuyệt đối không tự cộng số dư dựa trên ảnh chuyển khoản.

## Cài đặt
Xem `README-TERMIUS.md` để triển khai chi tiết trên Ubuntu/Debian bằng Termius.
