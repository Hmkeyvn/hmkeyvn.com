#!/usr/bin/env bash
set -euo pipefail
URL="${HMKEY_URL:-http://127.0.0.1:3000}"
curl --fail --silent --show-error "$URL/api/health"
echo
