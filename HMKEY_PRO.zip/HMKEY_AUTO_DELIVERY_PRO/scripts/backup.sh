#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${APP_DIR:-/var/www/hmkey/HMKEY_AUTO_DELIVERY_PRO}"
DB_NAME="${DB_NAME:-hmkey}"
BACKUP_DIR="${BACKUP_DIR:-$HOME/hmkey-backups}"
mkdir -p "$BACKUP_DIR"
STAMP="$(date +%F-%H%M%S)"
sudo -u postgres pg_dump "$DB_NAME" > "$BACKUP_DIR/${DB_NAME}-${STAMP}.sql"
tar -czf "$BACKUP_DIR/private-files-${STAMP}.tar.gz" -C "$APP_DIR" private-files
echo "Backup created in $BACKUP_DIR"
